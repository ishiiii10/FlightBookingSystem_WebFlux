package com.FlightBooking.enums;

public enum MealType {
	VEG, NON_VEG, NONE

}
