package com.FlightBooking.enums;

public enum TripType {
	ONE_WAY, ROUND_TRIP

}
