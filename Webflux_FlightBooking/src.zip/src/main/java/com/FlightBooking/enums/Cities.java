package com.FlightBooking.enums;

public enum Cities {
	DELHI, MUMBAI, BANGALORE, CHENNAI, KOLKATA, HYDERABAD, PUNE, JAIPUR, PATNA

}
