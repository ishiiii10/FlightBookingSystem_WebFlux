package com.FlightBooking.enums;

public enum BookingStatus {
	BOOKED, CANCELLED, PENDING

}
