package com.FlightBooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebfluxFlightBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebfluxFlightBookingApplication.class, args);
	}

}
