package com.FlightBooking.controller;

import com.FlightBooking.dto.request.FlightRequest;
import com.FlightBooking.dto.request.FlightSearchRequest;
import com.FlightBooking.dto.response.FlightResponse;
import com.FlightBooking.dto.response.FlightSearchResultResponse;
import com.FlightBooking.enums.Cities;
import com.FlightBooking.enums.TripType;
import com.FlightBooking.service.AirlineService;
import com.FlightBooking.service.BookingService;
import com.FlightBooking.service.FlightService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class FlightControllerTest {

	private WebTestClient webTestClient;

	@Mock
	private AirlineService airlineService;

	@Mock
	private FlightService flightService;

	@Mock
	private BookingService bookingService;

	@BeforeEach
	void setup() {
		// create controller manually and bind to WebTestClient
		FlightBookingController controller = new FlightBookingController(airlineService, flightService, bookingService);

		webTestClient = WebTestClient.bindToController(controller).build();
	}

	@Test
	void addFlight_returns201WithIdAndCode() {
		FlightRequest req = new FlightRequest();
		req.setAirlineId("AIRLINE_ID");
		req.setAirlineCode("AI");
		req.setAirlineName("AirIndia");
		req.setFlightCode("AI201");
		req.setFromCity(Cities.DELHI);
		req.setToCity(Cities.MUMBAI);
		req.setDepartureTime(LocalDateTime.of(2025, 12, 1, 10, 0));
		req.setPrice(5500f);
		req.setTotalSeats(120);

		FlightResponse resp = new FlightResponse();
		resp.setId("FLIGHT_ID");
		resp.setFlightCode("AI201");

		Mockito.when(flightService.addFlightToInventory(Mockito.any(FlightRequest.class))).thenReturn(Mono.just(resp));

		webTestClient.post().uri("/api/v1.0/flight/airline/inventory").contentType(MediaType.APPLICATION_JSON)
				.bodyValue(req).exchange().expectStatus().isCreated().expectBody().jsonPath("$.id")
				.isEqualTo("FLIGHT_ID").jsonPath("$.flightCode").isEqualTo("AI201");
	}

	@Test
	void searchFlight_roundTrip_returnsOnwardAndReturn() {
		FlightSearchRequest request = new FlightSearchRequest();
		request.setFromCity(Cities.DELHI);
		request.setToCity(Cities.MUMBAI);
		request.setJourneyDate(LocalDate.of(2025, 12, 1));
		request.setTripType(TripType.ROUND_TRIP);
		request.setReturnDate(LocalDate.of(2025, 12, 5));

		FlightResponse onward = new FlightResponse();
		onward.setId("F1");
		onward.setFlightCode("AI201");

		FlightResponse ret = new FlightResponse();
		ret.setId("F2");
		ret.setFlightCode("AI202");

		FlightSearchResultResponse serviceResp = new FlightSearchResultResponse();
		serviceResp.setTripType(TripType.ROUND_TRIP);
		serviceResp.setOnwardFlights(List.of(onward));
		serviceResp.setReturnFlights(List.of(ret));

		Mockito.when(flightService.searchFlights(Mockito.any(FlightSearchRequest.class)))
				.thenReturn(Mono.just(serviceResp));

		webTestClient.post().uri("/api/v1.0/flight/search").contentType(MediaType.APPLICATION_JSON).bodyValue(request)
				.exchange().expectStatus().isOk().expectBody().jsonPath("$.tripType").isEqualTo("ROUND_TRIP")
				.jsonPath("$.onwardFlights[0].flightCode").isEqualTo("AI201").jsonPath("$.returnFlights[0].flightCode")
				.isEqualTo("AI202");
	}
}