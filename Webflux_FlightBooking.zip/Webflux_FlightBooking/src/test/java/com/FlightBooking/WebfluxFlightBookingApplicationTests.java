package com.FlightBooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfluxFlightBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
